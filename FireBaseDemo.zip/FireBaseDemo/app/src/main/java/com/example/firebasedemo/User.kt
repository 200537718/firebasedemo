package com.example.firebasedemo

data class User(
    val id: String?= null,
    val name: String?= null,
    val age: String?= null,
    val address: String?= null,
    val email: String?= null
)

